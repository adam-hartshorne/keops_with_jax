Pytorch API
---------------------
